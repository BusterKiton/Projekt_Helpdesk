from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.models import User, auth
from django.contrib import messages
from .models import Profile, Ticket
from .serializers import TicketSerializer
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.authtoken.models import Token
from rest_framework.permissions import IsAuthenticated
from django.contrib.auth import authenticate, login as auth_login
from rest_framework import status
from django.views.decorators.csrf import csrf_exempt
from django.utils.decorators import method_decorator
from django.contrib.auth import get_user_model
import logging
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.parsers import MultiPartParser, FormParser
from .models import Profile, FileAttachment, Ticket
from .serializers import FileAttachmentSerializer, TicketSerializer
from django.core.cache import cache
import redis

# API Endpoint do przesyłania plików
class FileUploadView(APIView):
    parser_classes = (MultiPartParser, FormParser)

    def post(self, request, ticket_id, *args, **kwargs):
        try:
            # Pobierz zgłoszenie
            ticket = Ticket.objects.get(id=ticket_id)

            # Pobierz plik
            file = request.FILES['file']

            # Walidacja rozmiaru pliku
            if file.size > 10 * 1024 * 1024:  # 10 MB limit
                return Response({"error": "File too large"}, status=400)

            # Tworzenie załącznika
            attachment = FileAttachment.objects.create(
                ticket=ticket,
                uploaded_by=request.user,
                file=file
            )
            return Response(FileAttachmentSerializer(attachment).data, status=201)
        except Ticket.DoesNotExist:
            return Response({"error": "Ticket not found"}, status=404)
        except Exception as e:
            return Response({"error": str(e)}, status=500)


# API Endpoint do listy zgłoszeń
class TicketListView(APIView):
    def get(self, request):
        tickets = Ticket.objects.all()
        serializer = TicketSerializer(tickets, many=True)
        return Response(serializer.data)

User = get_user_model()

logger = logging.getLogger(__name__)


class HelloWorld(APIView):
    permission_classes = [IsAuthenticated]

    def get(self, request):
        return Response({"message": "Hello from Django!"})


# Create your views here.
def index(request):
    return render(request, 'index.html')


class RegisterView(APIView):
    def post(self, request):
        username = request.data.get('username')
        email = request.data.get('email')
        password = request.data.get('password')
        is_employee = request.data.get('is_employee', False)

        # Walidacja pustych pól
        if not username or not email or not password:
            return Response({"message": "Wszystkie pola są wymagane."}, status=status.HTTP_400_BAD_REQUEST)

        # Sprawdzenie, czy użytkownik już istnieje
        if User.objects.filter(username=username).exists():
            return Response({"message": "Użytkownik o podanej nazwie już istnieje."},
                            status=status.HTTP_400_BAD_REQUEST)

        if User.objects.filter(email=email).exists():
            return Response({"message": "Użytkownik z podanym adresem e-mail już istnieje."},
                            status=status.HTTP_400_BAD_REQUEST)

        # Tworzenie użytkownika
        user = User.objects.create_user(username=username, email=email, password=password)
        if hasattr(user, 'profile'):  # Jeśli istnieje model Profile
            user.profile.is_employee = is_employee
            user.profile.save()

        return Response({"message": "Rejestracja zakończona sukcesem."}, status=status.HTTP_201_CREATED)


User = get_user_model()
logger = logging.getLogger(__name__)


@method_decorator(csrf_exempt, name='dispatch')
@method_decorator(csrf_exempt, name='dispatch')
class LoginAPIView(APIView):
    def post(self, request):
        username = request.data.get('username')
        password = request.data.get('password')

        if not username or not password:
            return Response({"message": "Wszystkie pola są wymagane."}, status=status.HTTP_400_BAD_REQUEST)

        user = authenticate(request, username=username, password=password)

        if user is not None:
            token, _ = Token.objects.get_or_create(user=user)
            return Response({"message": "Logowanie zakończone sukcesem.", "token": token.key},
                            status=status.HTTP_200_OK)
        else:
            return Response({"message": "Nieprawidłowe dane logowania."}, status=status.HTTP_401_UNAUTHORIZED)


def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        password2 = request.POST['password2']
        user_rights = request.POST.get('user_rights', 'user')  # Domyślnie 'user'

        if password == password2:
            if User.objects.filter(email=email).exists():
                messages.info(request, 'Email już istnieje')
                return redirect('register')
            elif User.objects.filter(username=username).exists():
                messages.info(request, 'Nazwa użytkownika jest zajęta')
                return redirect('register')
            else:
                user = User.objects.create_user(username=username, email=email, password=password)
                user.save()

                # Ustaw prawa użytkownika
                profile = Profile.objects.get(user=user)
                profile.user_rights = user_rights
                profile.save()

                return redirect('login')
        else:
            messages.info(request, 'Hasła nie są te same')
            return redirect('register')
    else:
        return render(request, 'register.html')


def panel_admina(request):
    return render(request, 'panel_admina.html')


def panel_usera(request):
    return render(request, 'panel_usera.html')


User = get_user_model()


def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')

        if not username or not password:
            messages.error(request, 'Wszystkie pola są wymagane.')
            return redirect('login')

        user = authenticate(request, username=username, password=password)

        if user is not None:
            auth_login(request, user)

            if hasattr(user, 'profile') and user.profile.user_rights == 'admin':
                return redirect('panel_admina')
            else:
                return redirect('panel_usera')
        else:
            messages.error(request, 'Nieprawidłowe dane logowania.')
            return redirect('login')

    return render(request, 'login.html')


# Tickets Vievs

class UserTicketsApiView(APIView):
    permission_classes = [IsAuthenticated]
    valid_roles = ['admin', 'user', 'worker']

    def get(self, request):
        user = request.user
        profile = Profile.objects.by_user(user).first()
        if profile.user_rights in self.valid_roles:
            tasks = Ticket.objects.by_requester(profile)
            serializer = TicketSerializer(tasks, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response(
                {'message': 'Błąd autoryzacji'},
                status=status.HTTP_400_BAD_REQUEST
            )

    def post(self, request):
        user = request.user
        profile = Profile.objects.by_user(user).first()
        if profile.user_rights in self.valid_roles:
            data = request.data.copy()
            data['requester'] = profile.id
            serializer = TicketSerializer(data=data)
            if serializer.is_valid():
                serializer.save()
                return Response(serializer.data, status=status.HTTP_201_CREATED)
            return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
        else:
            return Response(
                {'message': 'Błąd autoryzacji'},
                status=status.HTTP_401_UNAUTHORIZED
            )


class FreeTicketsApiView(APIView):
    permission_classes = [IsAuthenticated]
    valid_roles = ['admin', 'worker']

    def get(self, request):
        user = request.user
        profile = Profile.objects.by_user(user).first()
        if profile.user_rights in self.valid_roles:
            tasks = Ticket.objects.free_tickets()
            serializer = TicketSerializer(tasks, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response(
                {'message': 'Błąd autoryzacji'},
                status=status.HTTP_400_BAD_REQUEST
            )


class TakeTicketsApiView(APIView):
    permission_classes = [IsAuthenticated]
    valid_roles = ['admin', 'worker']

    def put(self, request, id):
        user = request.user
        profile = Profile.objects.by_user(user).first()
        if profile.user_rights in self.valid_roles:
            obj = get_object_or_404(Ticket, id=id)
            if obj.handler_worker is None:
                obj.handler_worker = profile
                obj.save()  # Zapisanie zmian w obiekcie Ticket
                return Response({'message': "Przyjęto zgłoszenie"}, status=status.HTTP_200_OK)

            else:
                return Response(
                    {'message': 'Zgłoszenie zajęte'},
                    status=status.HTTP_401_UNAUTHORIZED
                )

        else:
            return Response(
                {'message': 'Błąd autoryzacji'},
                status=status.HTTP_401_UNAUTHORIZED
            )


class WorkerTicketsApiView(APIView):
    permission_classes = [IsAuthenticated]
    valid_roles = ['admin', 'worker']

    def get(self, request):
        user = request.user
        profile = Profile.objects.by_user(user).first()
        if profile.user_rights in self.valid_roles:
            tasks = Ticket.objects.by_worker(profile)
            serializer = TicketSerializer(tasks, many=True)
            return Response(serializer.data, status=status.HTTP_200_OK)
        else:
            return Response(
                {'message': 'Błąd autoryzacji'},
                status=status.HTTP_401_UNAUTHORIZED
            )


class TicketApiView(APIView):
    permission_classes = [IsAuthenticated]
    workers_roles = ['admin', 'worker']
    valid_roles = ['admin', 'user', 'worker']

    def get(self, request, id):
        user = request.user
        profile = Profile.objects.by_user(user).first()
        if profile.user_rights in self.valid_roles:
            obj = get_object_or_404(Ticket, id=id)
            if ((profile.user_rights == 'user' and profile.id == obj.requester.id) or
                    (profile.user_rights in self.workers_roles)):
                serializer = TicketSerializer(obj)
                return Response(serializer.data)
            else:
                return Response(
                    {'message': 'Błąd autoryzacji1'},
                    status=status.HTTP_401_UNAUTHORIZED
                )
        else:
            return Response(
                {'message': 'Błąd autoryzacji'},
                status=status.HTTP_401_UNAUTHORIZED
            )

    def put(self, request, id):
        user = request.user
        profile = Profile.objects.by_user(user).first()
        if profile.user_rights in self.valid_roles:
            obj = get_object_or_404(Ticket, id=id)
            if ((profile.user_rights == 'user' and profile.id == obj.requester.id) or
                    (profile.user_rights in self.workers_roles)):
                serializer = TicketSerializer(obj, data=request.data, partial=True)
                if serializer.is_valid():
                    serializer.save()
                    return Response(serializer.data)
                return Response(serializer.errors, status=status.HTTP_400_BAD_REQUEST)
            else:
                return Response(
                    {'message': 'Błąd autoryzacji1'},
                    status=status.HTTP_401_UNAUTHORIZED
                )
        else:
            return Response(
                {'message': 'Błąd autoryzacji'},
                status=status.HTTP_401_UNAUTHORIZED
            )

    def delete(self, request, id):
        user = request.user
        profile = Profile.objects.by_user(user).first()
        if profile.user_rights in self.workers_roles:
            obj = get_object_or_404(Ticket, id=id)
            obj.delete()
            answer = 'Usunięto pomyślnie id: ' + str(id)
            return Response({'message': answer}, status.HTTP_200_OK)
        else:
            return Response(
                {'message': 'Błąd autoryzacji'},
                status=status.HTTP_401_UNAUTHORIZED
            )
